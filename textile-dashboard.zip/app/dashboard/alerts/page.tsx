"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { AlertCenter } from "@/components/alerts/alert-center"
import { useAlerts } from "@/hooks/use-alerts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, CheckCircle } from "lucide-react"

export default function AlertsPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()
  const { alerts, unreadCount, resolveAlert, dismissAlert, clearAllAlerts } = useAlerts()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return null
  }

  const activeAlerts = alerts.filter((a) => !a.resolved)
  const resolvedAlerts = alerts.filter((a) => a.resolved)
  const highSeverityAlerts = activeAlerts.filter((a) => a.severity === "high").length

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Alert Management</h1>
          <p className="text-muted-foreground">Monitor and manage production alerts</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Active Alerts</p>
                  <p className="text-3xl font-bold text-foreground">{activeAlerts.length}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">High Severity</p>
                  <p className="text-3xl font-bold text-red-400">{highSeverityAlerts}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Resolved</p>
                  <p className="text-3xl font-bold text-green-400">{resolvedAlerts.length}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Alert Center */}
        <AlertCenter alerts={alerts} onResolve={resolveAlert} onDismiss={dismissAlert} onClearAll={clearAllAlerts} />

        {/* Alert Statistics */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg">Alert Statistics</CardTitle>
            <CardDescription>Alert distribution by type and severity</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* By Type */}
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-4">By Type</h3>
                <div className="space-y-3">
                  {["bottleneck", "fault", "quality", "maintenance"].map((type) => {
                    const count = alerts.filter((a) => a.type === type && !a.resolved).length
                    return (
                      <div key={type} className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground capitalize">{type}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-24 bg-muted rounded-full h-2">
                            <div
                              className="bg-primary h-2 rounded-full"
                              style={{ width: `${Math.min(100, count * 20)}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-semibold text-foreground w-8 text-right">{count}</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* By Severity */}
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-4">By Severity</h3>
                <div className="space-y-3">
                  {["high", "medium", "low"].map((severity) => {
                    const count = alerts.filter((a) => a.severity === severity && !a.resolved).length
                    const color =
                      severity === "high" ? "bg-red-500" : severity === "medium" ? "bg-yellow-500" : "bg-blue-500"
                    return (
                      <div key={severity} className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground capitalize">{severity}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-24 bg-muted rounded-full h-2">
                            <div
                              className={`${color} h-2 rounded-full`}
                              style={{ width: `${Math.min(100, count * 20)}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-semibold text-foreground w-8 text-right">{count}</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
