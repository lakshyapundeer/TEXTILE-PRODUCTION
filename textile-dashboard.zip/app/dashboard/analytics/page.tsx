"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { ProductionAnalytics } from "@/components/analytics/production-analytics"
import { PerformanceMetrics } from "@/components/analytics/performance-metrics"
import { ReportGenerator } from "@/components/analytics/report-generator"

export default function AnalyticsPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
    // Only allow floor managers and admins
    if (!isLoading && user && !["floor_manager", "admin"].includes(user.role)) {
      router.push("/dashboard")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return null
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Production Analytics</h1>
          <p className="text-muted-foreground">Comprehensive production metrics and performance reports</p>
        </div>

        <ProductionAnalytics />
        <PerformanceMetrics />
        <ReportGenerator />
      </div>
    </DashboardLayout>
  )
}
