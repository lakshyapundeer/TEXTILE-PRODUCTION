"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { OperatorDashboard } from "@/components/dashboard/operator-dashboard"
import { FloorManagerDashboard } from "@/components/dashboard/floor-manager-dashboard"
import { AdminDashboard } from "@/components/dashboard/admin-dashboard"
import { QCStaffDashboard } from "@/components/dashboard/qc-staff-dashboard"

export default function DashboardPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-foreground">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  const renderDashboard = () => {
    switch (user.role) {
      case "operator":
        return <OperatorDashboard />
      case "floor_manager":
        return <FloorManagerDashboard />
      case "admin":
        return <AdminDashboard />
      case "qc_staff":
        return <QCStaffDashboard />
      default:
        return <div>Unknown role</div>
    }
  }

  return <DashboardLayout>{renderDashboard()}</DashboardLayout>
}
