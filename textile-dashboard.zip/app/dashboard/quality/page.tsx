"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { BradeProductForm } from "@/components/quality/bgrade-product-form"
import { BradeProductsList } from "@/components/quality/bgrade-products-list"
import { BradeAnalytics } from "@/components/quality/bgrade-analytics"

export default function QualityPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return null
  }

  const canReportDefects = ["qc_staff", "floor_manager", "admin"].includes(user.role)

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Quality Control</h1>
          <p className="text-muted-foreground">Manage B-Grade products and quality issues</p>
        </div>

        {/* Analytics Overview */}
        <BradeAnalytics />

        {/* Report Form and List */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {canReportDefects && (
            <div className="lg:col-span-1">
              <BradeProductForm />
            </div>
          )}
          <div className={canReportDefects ? "lg:col-span-2" : "lg:col-span-3"}>
            <BradeProductsList />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
