"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { GanttChart } from "@/components/dashboard/gantt-chart"
import { TaskManager } from "@/components/dashboard/task-manager"
import { mockTasks } from "@/lib/mock-data"

export default function SchedulingPage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
    // Only allow floor managers and admins
    if (!isLoading && user && !["floor_manager", "admin"].includes(user.role)) {
      router.push("/dashboard")
    }
  }, [user, isLoading, router])

  if (isLoading || !user) {
    return null
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Task Scheduling</h1>
          <p className="text-muted-foreground">Manage production tasks and machine assignments</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <GanttChart tasks={mockTasks} />
          </div>
          <div>
            <TaskManager />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
